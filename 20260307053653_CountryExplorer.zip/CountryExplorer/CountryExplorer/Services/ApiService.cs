﻿using CountryExplorer.Models;
using System.Text.Json;

namespace CountryExplorer.Services
{
    public class ApiService
    {
        public async Task<List<Country>> GetCountries()
        {
            using var httpClient = new HttpClient();

            string url = "https://restcountries.com/v3.1/all?fields=name,capital,region,subregion,population,flags";

            var response = await httpClient.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception("Erreur API : " + response.StatusCode);
            }

            var json = await response.Content.ReadAsStringAsync();

            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            var countries = JsonSerializer.Deserialize<List<Country>>(json, options);

            return countries ?? new List<Country>();
        }
    }
}