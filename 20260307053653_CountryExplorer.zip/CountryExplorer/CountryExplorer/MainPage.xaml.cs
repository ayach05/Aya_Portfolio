using CountryExplorer.Models;
using CountryExplorer.Services;

namespace CountryExplorer
{
    public partial class MainPage : ContentPage
    {
        ApiService apiService = new ApiService();
        List<Country> allCountries = new List<Country>();
        bool countriesLoaded = false;

        public MainPage()
        {
            InitializeComponent();
        }

        private async void OnLoadCountriesClicked(object sender, EventArgs e)
        {
            try
            {
                LoadingIndicator.IsVisible = true;
                LoadingIndicator.IsRunning = true;

                allCountries = await apiService.GetCountries();

                CountriesList.ItemsSource = allCountries
                    .OrderBy(c => c.Name.Common)
                    .ToList();

                countriesLoaded = true;
            }
            catch (Exception ex)
            {
                await DisplayAlert("Erreur", ex.Message, "OK");
            }
            finally
            {
                LoadingIndicator.IsRunning = false;
                LoadingIndicator.IsVisible = false;
            }
        }

        private void OnSearchTextChanged(object sender, TextChangedEventArgs e)
        {
            if (!countriesLoaded)
                return;

            string text = e.NewTextValue?.ToLower() ?? "";

            if (string.IsNullOrWhiteSpace(text))
            {
                CountriesList.ItemsSource = allCountries
                    .OrderBy(c => c.Name.Common)
                    .ToList();
                return;
            }

            var filtered = allCountries
                .Where(c => c.Name != null &&
                            c.Name.Common != null &&
                            c.Name.Common.ToLower().Contains(text))
                .OrderBy(c => c.Name.Common)
                .ToList();

            CountriesList.ItemsSource = filtered;
        }

        private async void OnCountrySelected(object sender, SelectionChangedEventArgs e)
        {
            var selectedCountry = e.CurrentSelection.FirstOrDefault() as Country;

            if (selectedCountry == null)
                return;

            await Navigation.PushAsync(new DetailsPage(selectedCountry));

            CountriesList.SelectedItem = null;
        }
    }
}