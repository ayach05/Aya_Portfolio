using CountryExplorer.Models;

namespace CountryExplorer
{
    public partial class DetailsPage : ContentPage
    {
        public DetailsPage(Country country)
        {
            InitializeComponent();
            BindingContext = country;
        }
    }
}