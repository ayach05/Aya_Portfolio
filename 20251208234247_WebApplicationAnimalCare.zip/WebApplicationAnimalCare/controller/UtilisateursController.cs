﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplicationAnimalCare.Controllers
{
    public class UtilisateursController : Controller
    {
        public IActionResult Index() => View();
    }
}
