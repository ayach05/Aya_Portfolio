﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplicationAnimalCare.Controllers
{
    public class RendezVousController : Controller
    {
        public IActionResult Index() => View();
        public IActionResult Create() => View();
        public IActionResult Details(int id) => View();
    }
}
