﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplicationAnimalCare.controller
{
    public class ProprietairesController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
