﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplicationAnimalCare.controller
{
    public class NotificationsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
