﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplicationAnimalCare.Controllers
{
    public class ReceptionController : Controller
    {
        public IActionResult Index() => View();
    }
}
