﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplicationAnimalCare.Controllers
{
    public class MedecinController : Controller
    {
        public IActionResult Index() => View();
    }
}
