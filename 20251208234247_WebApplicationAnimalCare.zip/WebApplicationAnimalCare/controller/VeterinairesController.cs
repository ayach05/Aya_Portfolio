﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplicationAnimalCare.controller
{
    public class VeterinairesController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
