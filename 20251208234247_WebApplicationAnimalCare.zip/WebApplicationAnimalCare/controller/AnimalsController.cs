﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplicationAnimalCare.controller
{
    public class AnimalsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
