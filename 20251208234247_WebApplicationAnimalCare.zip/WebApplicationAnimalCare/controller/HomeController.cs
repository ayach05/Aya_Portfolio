﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplicationAnimalCare.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index() => View();
    }
}
