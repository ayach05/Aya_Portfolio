﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplicationAnimalCare.controller
{
    public class HoraireVeterinairesController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
